package com.java.question19;

import java.util.ArrayList;

public class Question19 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		for (int i = 1; i <11; i++){
			al.add(i);             // creates array from 1-10
			
		}
		
		System.out.println("The Original Array : \n"+ al);  
		
		int countpos = 0;
		int countneg = 0;
		for (int i = 0; i <10; i++){
			if(al.get(i)%2 == 0){                // checks if number is positive
				countpos = countpos + al.get(i);  // add's numbers
			}
			else{
				countneg = countneg + al.get(i);  // add's negative numbers
			}
			
			
		}
		for (int i = 0; i < al.size() ; i++){      
		
			if (isPrime(al.get(i))){   //checks if number is prime
			al.remove(i);         // removes number from array
			i--;
		}
			
		}
	
		
		System.out.println("\n\nThe total of all even numbers is: " + countpos);
		System.out.println("The total of all odd numbers is: " + countneg);
		
		System.out.println("The new Array with no primes : \n"+ al);
		
	}
	
	public static boolean isPrime(int a){    // method which checks if number is prime
		if (a == 1 || a == 2 || a == 3 || a == 5 || a == 7) { 
			
			return true;
		} 
		
		else {
			return false; 
		}
		
	}

}
