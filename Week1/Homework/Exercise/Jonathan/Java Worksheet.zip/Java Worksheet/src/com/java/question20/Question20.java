package com.java.question20;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Question20 {
	BufferedReader br;
	static final String FILENAME = "Data.txt"; //Final variable which is the name of the text file I will be reading

	public static void main(String[] args) {

		Question20 fir = new Question20(); // New instance of the class to call the reader method

		try {
			fir.reader(FILENAME); //Method that will read the file
			                      //The try-catch block takes away the IOException in order to compile
		} catch (Exception e) {
			e.printStackTrace(); //if exception is caught it prints the stack trace
		}
	}

	public void reader(String filename) throws IOException {

		try {
			br = new BufferedReader(new FileReader(filename)); 
			String s = null;
			while((s = br.readLine())!=null){  // while there's still another line that hasn't been read
				
				StringTokenizer st = new StringTokenizer(s,":"); // Setting up tokenizer
				
	//Bellow is the printing format, each token is seperated by the delimiter ":" specified above
				System.out.println("Name: " + st.nextToken() + " " + st.nextToken());
				System.out.println("Age : "+ st.nextToken());  
				System.out.println("State : " + st.nextToken() + " State\n\n");
			}
			
				
		} catch (FileNotFoundException e) {  // Catching IOException
			e.printStackTrace();
		} finally {
			if (br != null) {
				br.close(); //closing stream
			}
		}
	}
}