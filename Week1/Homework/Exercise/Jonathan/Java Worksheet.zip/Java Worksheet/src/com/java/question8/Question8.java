package com.java.question8;

import java.util.ArrayList;
import java.util.List;

public class Question8 {

	public static void main(String[] args) {
		
		// creates array list 
		String list[] = {"karan", "madam", "tom", "civic", "radar", "sexes", "jimmy", "kayak", "john",  "refer", "billy", "did"};
		List<String> rlist = new ArrayList<String>();	
		
		for (int i = 0; i < list.length; i++){
			if (list[i].equals(reverse(list[i]))){  // checks if palindrome
				rlist.add(list[i]); // add's to list
			}
			
		}
		for(String j : rlist) {
            System.out.print(j + " ");  //prints out palindromes 
        }
	
	
	}

	
		
	// Re-used code from Question 3 to reverse string
	public static String reverse(String s){
		for (int i = 0; i < s.length(); i++) {
		    s = s.substring(1, s.length() - i) 
		        +s.substring(0, 1) 
		        + s.substring(s.length() - i, s.length()); 
		    
		 } 
		 return s;
	}
}


