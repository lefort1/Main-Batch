package com.java.question15;

public class Question15 {

	public static void main(String[] args) {
 
 LetUsMath a = new LetUsMath(); // creating new instance of LetUsMath
 
 int add = a.addition(8, 9); // calling methods declared in LetUsMath
 System.out.println(add);
 
 int sub = a.substraction(9, 8); 
 System.out.println(sub);
 
 int mul = a.multiplication(9, 8);
 System.out.println(mul);
 
 int div = a.division(9, 9);
 System.out.println(div);
 
 
	}

	
}
