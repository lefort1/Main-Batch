package com.java.question17;

import java.util.Scanner;  // importing scanner util.

public class Question17 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in); //creating new scanner object
		int interest;
		
		System.out.println("Please enter an amount for Principal: ");
		int principal = scan.nextInt();     // scanning principal
		
		System.out.println("Please enter your rate: ");
		int rate = scan.nextInt();  // scanning for rate
		
		System.out.println("Please enter a time: "); 
		int time = scan.nextInt();    // scanning for time 
		
		interest = principal* rate* time;
		
		
		
		
		
		interest = principal* rate* time;
		System.out.println("Your interest will be : $ " + interest);  // printing interest

	}

}
