package com.java.question13;

public class Question13 {

	public static void main(String[] args) {
		boolean bool = false;  
		for (int i=0; i < 4; i++ ){
			for (int j = 0; j < (i+1); j++){  
				
				
				if (bool){    // depending on if bool is true or not then the loop with print either 
					          // 0 or 1
					System.out.print(1);
				}
				else{
					System.out.print(0);
				}
				bool = !bool;
			}
			System.out.println(); // prints new line for next row 
			
		}

	}

}
