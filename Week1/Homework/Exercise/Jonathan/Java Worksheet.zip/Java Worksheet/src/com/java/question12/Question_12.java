package com.java.question12;

public class Question_12 {

	public static void main(String[] args) {
		
		int array[] = new int[100];

		for (int i = 0; i < 100; i++) { // creates array from 1-100
			array[i] = i + 1; 
		}
		
		for ( int i : array){  // goes through every int i in the array 
			if ((i%2)==0){   // checks if number is even
				System.out.print(i + " ");
			}
		}
		
	}

}
