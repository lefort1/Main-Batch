package com.java.question_11_1;

public class Question11_1 {
	
public static float f1 = 36.9F; // making public so that they can be used in another package
                                // and static so that they can be invoked without creating an instance of the class

public static float f2 = 24.1F;  // same thing here


}
