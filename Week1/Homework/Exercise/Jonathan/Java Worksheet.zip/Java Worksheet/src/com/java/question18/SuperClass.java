package com.java.question18;

public abstract class SuperClass {  // declaring abstract methods in the superclass

	public boolean isUpperCase;
	
	public String toLowercase;
	
	public int  stringToInt; 
	
	
}
