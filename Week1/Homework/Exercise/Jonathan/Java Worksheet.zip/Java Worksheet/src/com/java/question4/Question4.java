package com.java.question4;

public class Question4 {

	public static void main(String[] args) {
		
		
		int n = 9; // Number for n!
		
		for (int i = n; i > 1 ; i--){  // Goes down the numbers before n
			
			n *= (i-1); // Multiples n with previous numbers
			
		}
 System.out.println(n);
	}

}
