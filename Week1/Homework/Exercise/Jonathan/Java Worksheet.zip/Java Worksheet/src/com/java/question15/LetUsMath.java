package com.java.question15;

public class LetUsMath implements Arith{ // class that will implement methods from Arith

	@Override
	public int addition(int a, int b) {  // addtition
		int x;
		x = a + b;
		return x;
	}

	@Override
	public int substraction(int a, int b) { // subtraction
		int x;
		x = a - b;
		return x;
	}

	@Override
	public int multiplication(int a, int b) {  // multiplication
		int x;
		 x = a *  b;
		return x;
	}

	@Override
	public int division(int a, int b) {  // division
		int x;
		 x = a/b;
		
		return x;
	}

}
