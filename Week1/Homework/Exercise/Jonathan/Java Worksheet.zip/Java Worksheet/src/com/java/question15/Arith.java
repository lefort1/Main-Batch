package com.java.question15;

public interface Arith { // creating interface with methods that will be implemented

	public int addition(int a, int b); 

	public int substraction(int a, int b);

	public int multiplication(int a, int b);

	public int division(int a, int b);

}
