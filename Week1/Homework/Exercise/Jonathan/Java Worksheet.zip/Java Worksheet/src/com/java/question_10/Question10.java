package com.java.question_10;

public class Question10 {

	public static void main(String[] args) {
int number1 = 19;
int number2 = 24;

int min = (number1 < number2) ? number1 : number2;  // compares the numbers

System.out.println("The minimum number is : "+min); // prints result
	}

}
