package com.java.question7;

import java.util.ArrayList;

public class Question7 {

	public static void main(String[] args) {

		ArrayList<Employee> listp = new ArrayList<Employee>();
		listp.add(new Employee("Robbert","HR",36));
		listp.add(new Employee("Kevin","WareHouse",24));
		
		System.out.println(" Unsorted list : \n" + listp);
		
		listp.sort(new ComparatorByName());
		System.out.println("\n Sorted by name : \n" + listp);
		
		listp.sort(new ComparatorByDepartment());
		System.out.println("\n Sorted by Department : \n" + listp);
		
		listp.sort(new ComparatorByAge());
		System.out.println("\n Sorted by Age : \n" + listp);
		
		
		

	}

}
