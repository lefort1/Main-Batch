package com.java.question14;

import java.time.LocalDateTime;

public class Question14{

	public static void main(String[] args) {
		
		int x = 1;
		double a = 49;
		LocalDateTime timeNow = LocalDateTime.now(); // creating local time variable
		String s = new String();
		s = "I am learning Core Java";

		switch (x) {   // depending on value of x a case will be executed
		case 1: 
			a = Math.sqrt(a);
			System.out.println(a);
			break;                    // break statements so that scope is broken after case execution
		case 2: 
			System.out.print(timeNow);
			break;
		case 3:
			String sa[] = s.split(" ");
			System.out.println(sa[0]);
			System.out.println(sa[1]);
			System.out.println(sa[2]);
			break;
			
			
			
			
		}
	}

}
