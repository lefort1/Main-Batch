package com.java.question6;

public class Question6 {

	public static void main(String[] args) {
		int number = 9;    // Integer to be determined if even or odd
		
		if ((number/2) == ((number + 1)/2)){   
			// used int's function to my advantage, odd numbers divided by 2 round down therefore 
			// will be equal to half of the even number before them
			System.out.println("Number is Even");
		}
		else{
			System.out.println("Number is Odd");
		}

	}

}
