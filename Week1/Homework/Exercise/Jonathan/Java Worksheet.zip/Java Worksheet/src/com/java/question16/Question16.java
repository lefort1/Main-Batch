package com.java.question16;

import java.util.Arrays;

public class Question16 {

	public static void main(String[] args) {
		String sa[] = args;
		
		StringBuilder sbui = new StringBuilder();
		
		for(String s : sa ){
			sbui.append(s + " ");
		}
		
		System.out.println("Your String: "+ sbui);
		int x = sbui.length();
		System.out.println("The length of the string is " + x);

	}

}
