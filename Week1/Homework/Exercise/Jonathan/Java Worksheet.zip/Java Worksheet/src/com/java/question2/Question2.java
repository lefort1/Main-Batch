package com.java.question2;


public class Question2 {

	public static void main(String[] args) {
		int n[] = new int[25]; // initializing array of 25
		n[0] = 0; // setting first number to be 0 (Got to start somewhere)
		
      for (int i = 1; i < 25; i++){  
	
    	  if( i == 1){  // for the second number (To avoid runtime exceptions)
    		  n[i] = 1;  
    	  }
    	  else{    // For any numbers besides the first two
    		  
    		  n[i] = n[i-1] + n[i-2]; 
    	  }
	}
      
      for (int i = 0; i < n.length; i++){
			
			System.out.print(n[i]+ " ");  //printing array
				
		}
		

}
}
