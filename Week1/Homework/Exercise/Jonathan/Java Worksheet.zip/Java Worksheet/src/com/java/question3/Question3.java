package com.java.question3;

import java.util.Arrays;

// I actually coded this question so that you pass arguments into it.
// I made life harder for myself....

public class Question3 {

	public static void main(String[] args) {
      String s = Arrays.toString(args); //converting array to string

for (int i = 0; i < s.length(); i++) {
    s = s.substring(1, s.length() - i) // grabs the portion of the string that hasn't been reversed
        +s.substring(0, 1) // Grabs the new beginning character
        + s.substring(s.length() - i, s.length()); // keeps the reversed portion
    
 }
 s = s.substring(1, s.length()-1);  // removing brackets 
System.out.println(s);
}
}
