package com.java.question9;

public class Question9 {

	public static void main(String[] args) {
		int array[] = new int[100];

		for (int i = 0; i < 100; i++) { // creates array from 1-100
			array[i] = i + 1;
		}
		for (int j = 0; j < 100; j++) { // prints out prime numbers

			if (array[j] == 1) { // Rules out 1 as prime number

			} else if (array[j] == 2 || array[j] == 3 || array[j] == 5 || array[j] == 7) { //prints out the prime numbers form 2-7
				System.out.print(array[j] + " ");
			} else if ((array[j]) % 2 != 0 && (array[j]) % 3 != 0 && (array[j]) % 5 != 0 && (array[j]) % 7 != 0) { //prints out prime numbers from 1-100
				System.out.print(array[j] + " ");

			}

		}

	}

}
