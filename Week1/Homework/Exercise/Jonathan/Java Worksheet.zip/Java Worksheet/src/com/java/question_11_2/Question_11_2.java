package com.java.question_11_2;

import com.java.question_11_1.Question11_1; // importing package and class


public class Question_11_2 extends Question11_1{ // extending class to inherit variables

	public static void main(String[] args) {
       float f3 = f1 + f2;   // making use of inherited variables
       
       System.out.println(f3);
	}

}
