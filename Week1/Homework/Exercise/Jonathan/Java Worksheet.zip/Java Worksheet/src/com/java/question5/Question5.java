package com.java.question5;

public class Question5 {

	public static void main(String[] args) {
		
		String s = "My Example String";
		int index = 6;
		
		newSubstring(s,index);  // method call with string and index param
		
  
		
  
	}

	public static void newSubstring(String s, int a){  //New substring method
		
		char c[] = s.toCharArray();   // convert string to character array
		
		for (int i = 0; i <= a; i++){   //go through array and prints out char up to index
			
			System.out.print(c[i]);   
		}
		
	}
}
