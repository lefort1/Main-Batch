package com.java.question18;

public class Question18 {

	public static void main(String[] args) {
		
		String s = "How are you today";
		boolean bool = false;
		int x = 0;
		
		SubClass sub = new SubClass();
		
		bool = sub.isUpperCase(s);  // calling uppercase method and depending on true or false
		                            // it will print out the corresponding message
		if (bool){
			System.out.println("There's an uppercase letter in the string \n\n" );

		}
		else{
			System.out.println("There's no upper case letter in the string");
		}
		
		x = sub.stringToInt(s); // calls StringToInt and returns an interger whcih is then passed ot x
	
		System.out.println("The number of the string is " + x + "\n\n\n");
		
		s = sub.toLowercase(s); // calls toLowerCase method which capitalizes all the letters
		
		System.out.println(s);

	}

}
