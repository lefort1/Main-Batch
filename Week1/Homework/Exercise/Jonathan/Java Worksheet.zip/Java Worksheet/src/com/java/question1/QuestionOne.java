package com.java.question1;

public class QuestionOne {

	public static void main(String[] args) {
		
			int array[] = {1,0,5,6,3,2,3,7,9,8,4};  //initializing array
			int temp=0; // temporary variable used for swap
		
			for (int j=0; j < array.length; j++){ // loop used to sort array again
		for (int i = 0; i < array.length -1;i++){ // loop used to through array
			
			temp = 0;
			
			if (array[i+1] < array[i]){
				
				temp = array[i];
				array[i] = array[i+1];  // swap method
				array[i+1] = temp;
				
			}
				
		}
			}
		for (int i = 0; i < array.length; i++){
			
			System.out.print(array[i]+ " ");  //printing array
				
		}
		
 
	}

}
