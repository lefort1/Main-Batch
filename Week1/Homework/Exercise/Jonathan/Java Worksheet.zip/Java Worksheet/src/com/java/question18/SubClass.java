package com.java.question18;

public class SubClass extends SuperClass{
	
	public boolean isUpperCase(String s){
		char[] ch=s.toCharArray();        // converts string to array
		for (char j : ch){
			if (Character.isUpperCase(j) == true){ //checks  if characters in string are uppercase
				                                   // if one is than it immediately returns true
			return true;
			}
		}
		return false;
		
	}
	
	
	public String toLowercase(String a){

		char ch[] = a.toCharArray();  // converts string to char array
		StringBuilder sb = new StringBuilder();

		for (char j : ch) {
			if (Character.isLowerCase(j) == true) { //checks if char is lowercase
				j = Character.toUpperCase(j); // if it is than it becomes uppercase
			}
			sb.append(j); //creates new string where all the characters should be Uppercase
		}

		 a = sb.toString(); //putting stringbuilder into a string for return type
		return a;
	}
	
	public int stringToInt(String s){
		
		char ch[] = s.toCharArray(); // converts string to char array
		int number = 0; 
		
		for (char j : ch) {
			number = number + j; //add's the character values of the string characters together 
		}
		
		number = number + 10; //add's 10
	
		return number;
		
		
	}; 
}
